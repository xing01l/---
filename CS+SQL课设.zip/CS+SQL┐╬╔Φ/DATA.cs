﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSQL课设
{
    internal class DATA
    {
        public static string userid = "", username = "",usersfz="",userxm="",usersex="";//暂存用户信息方便使用,id是用户名，name是密码
    }
}
